from django.apps import AppConfig


class AmioblogConfig(AppConfig):
    name = 'blogapp'
