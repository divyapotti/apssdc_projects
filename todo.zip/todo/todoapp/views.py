from django.shortcuts import render,redirect
from django.http import HttpResponse
from todoapp.models import *
from todoapp.forms import *

# Create your views here.
def index(request):
	obj = Content.objects.all()
	return render(request,'todoapp/index.html',{'obj':obj})
def Delete(request,id):
	data = Content.objects.get(id=id)
	data.delete()
	obj = Content.objects.all()
	return render(request,'todoapp/index.html',{'obj':obj})
def Add(request):
	if request.method=='POST':
		data=Content(content=request.POST['addit'])
		data.save()
		obj = Content.objects.all()
		return render(request,'todoapp/index.html',{'obj':obj})
	return render(request,'todoapp/index.html',{'obj':obj})

